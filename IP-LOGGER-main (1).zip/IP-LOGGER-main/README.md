# IP-LOGGER 
Please change the given grabify link to yours or else the ip will go to my link,  
Please make sure to have a text editer like visual studio or notepad++.
